import React from 'react';
import Editor, { OnMount } from '@monaco-editor/react';
import { Copy, Check, FileCode } from 'lucide-react';
import clsx from 'clsx';

interface EditorWindowProps {
  code: string;
  language: string;
  onChange?: (value: string | undefined) => void;
  readOnly?: boolean;
  title: string;
  placeholder?: string;
  loading?: boolean;
  headerActions?: React.ReactNode;
}

const EditorWindow: React.FC<EditorWindowProps> = ({ 
  code, 
  language, 
  onChange, 
  readOnly = false, 
  title,
  placeholder,
  loading,
  headerActions
}) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-700 rounded-lg overflow-hidden shadow-xl">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-2 overflow-hidden">
          <FileCode className="w-4 h-4 text-blue-400 shrink-0" />
          <span className="text-sm font-semibold text-slate-200 truncate" title={title}>{title}</span>
          {readOnly && code && (
             <span className="text-xs px-2 py-0.5 rounded bg-green-900/50 text-green-400 border border-green-700/50 shrink-0">
               English
             </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {headerActions}
          {!loading && code && (
            <>
              <div className="w-px h-4 bg-slate-600 mx-1"></div>
              <button
                onClick={handleCopy}
                className="p-1.5 text-slate-400 hover:text-white transition-colors hover:bg-slate-700 rounded-md"
                title="Copy code"
              >
                {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Editor Area */}
      <div className="relative flex-1 bg-[#1e1e1e]">
        {loading && (
           <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-slate-900/80 backdrop-blur-sm">
             <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-500 mb-4"></div>
             <p className="text-blue-400 font-medium animate-pulse">Translating...</p>
           </div>
        )}
        
        <Editor
          height="100%"
          language={language}
          value={code}
          theme="vs-dark"
          onChange={onChange}
          options={{
            readOnly: readOnly,
            minimap: { enabled: false },
            fontSize: 14,
            lineNumbers: 'on',
            scrollBeyondLastLine: false,
            automaticLayout: true,
            fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
            padding: { top: 16, bottom: 16 },
            renderWhitespace: 'selection',
            bracketPairColorization: { enabled: true },
          }}
          loading={
            <div className="flex items-center justify-center h-full text-slate-400">
              Loading Editor...
            </div>
          }
        />
        
        {!code && !readOnly && !loading && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             <span className="text-slate-600 text-sm">
               {placeholder || "Paste your code here..."}
             </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default EditorWindow;