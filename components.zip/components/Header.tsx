import React from 'react';
import { Languages, Github, Sparkles } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="flex items-center justify-between px-6 py-4 bg-slate-900 border-b border-slate-700">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-blue-600 rounded-lg shadow-lg shadow-blue-500/20">
          <Languages className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">Code Translator</h1>
          <p className="text-xs text-slate-400">Chinese to English • Preserving Logic</p>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <a 
          href="#"
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-300 transition-colors rounded-full hover:bg-slate-800 hover:text-white"
        >
          <Github className="w-4 h-4" />
          <span>Source</span>
        </a>
        <div className="flex items-center gap-2 px-3 py-1 bg-blue-900/30 border border-blue-500/30 rounded-full text-blue-300 text-xs">
           <Sparkles className="w-3 h-3" />
           <span>Powered by Gemini 3 Flash</span>
        </div>
      </div>
    </header>
  );
};

export default Header;