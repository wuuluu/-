import { GoogleGenAI } from "@google/genai";
import { TranslateMode } from '../types';

const MODEL_NAME = 'gemini-3-flash-preview';

export const translateCode = async (
  code: string, 
  language: string, 
  mode: TranslateMode
): Promise<string> => {
  if (!code.trim()) return '';
  if (!process.env.API_KEY) {
    throw new Error("API Key not found in environment variables.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  let systemInstruction = `
You are an expert Senior Software Engineer specialized in Code Localization and Internationalization.
Your task is to translate Chinese (Simplified/Traditional) content within source code into professional English.

RULES:
1. **Preserve Logic**: Do NOT change the code's functional logic, control flow, or structure. The compiled/interpreted output must remain functionally identical (except for the text content changes).
2. **Preserve Punctuation**: Keep all brackets, braces, semicolons, and operators exactly as they are.
3. **No Markdown**: Output ONLY the raw code. Do not wrap in markdown \`\`\` code blocks.
`;

  if (mode === TranslateMode.COMMENTS_ONLY) {
    systemInstruction += `
4. **Scope - Comments Only**: 
   - Translate ONLY the text inside comments (e.g., //, /* */, #, <!-- -->).
   - Do NOT translate string literals (e.g., "错误", '你好'). Keep string values exactly as is to ensure runtime output matches the original exactly.
   - Do NOT translate variable names.
`;
  } else {
    systemInstruction += `
4. **Scope - Full Translation**:
   - Translate text inside comments.
   - Translate text inside string literals (e.g., "请输入" -> "Please enter").
   - If a variable, function, or class name is written in Chinese characters (e.g., \`const 计数 = 0\`), translate it to a meaningful English CamelCase/snake_case name (e.g., \`const count = 0\`).
   - CAUTION: If a string literal looks like a dictionary key or database column name that must match an external system, try to use your best judgement to keep it or add a comment next to it.
`;
  }

  systemInstruction += `
5. **Quality**: The English translation should be technical, concise, and grammatically correct.
`;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: [
        {
          role: 'user',
          parts: [
            { text: `Language: ${language}\n\nSource Code:\n${code}` }
          ]
        }
      ],
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.1, // Low temperature for deterministic code output
      }
    });

    let translated = response.text || '';
    
    // Strip markdown if the model disregarded the instruction
    if (translated.startsWith('```')) {
      const lines = translated.split('\n');
      if (lines.length > 2) {
        // Remove first line (```lang) and last line (```)
        translated = lines.slice(1, -1).join('\n');
      }
    }

    return translated;
  } catch (error) {
    console.error("Gemini Translation Error:", error);
    throw new Error("Failed to translate code. Please try again.");
  }
};